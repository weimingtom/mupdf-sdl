
https://github.com/ArtifexSOftware/MuPDF.NET
MuPDF.NET.Test/resources
ArtifexSOftware_MuPDF.NET-main.zip

https://mupdf.com/releases

mupdf-1.9a-source.tar.gz

https://github.com/PSP-Archive/MuPDF-PSP  
https://github.com/SeanOMik/eBookReaderSwitch
https://github.com/GerHobbelt/mupdf/blob/master/platform/x11/warpapp.c
https://github.com/ehmry/genode/blob/sigil/repos/libports/src/app/pdf_view/main.cc
https://github.com/rofl0r/SDLBook 


==
mingw32:
	make -f Makefile.mingw clean
	make -f Makefile.mingw all -j8
	make -f Makefile.mingw test
	